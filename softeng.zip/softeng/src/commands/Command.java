package commands;

public interface Command {
	public String execute();	
	
}
