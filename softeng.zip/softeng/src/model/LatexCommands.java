package model;

public class LatexCommands {
	protected String command;
	public String getContent() {
		return command;
	}
}
