package model;

public class Blank extends Document {
	public Blank() {
		this.content="";
	}
	
}
