package model;

public class EnumList extends LatexCommands {

	public EnumList() {
		this.command = "\n\\begin{enumerate}\r\n\n" + 
				"\\item ...\r\n\n" + 
				"\\item ...\r\n\n" + 
				"\\end{enumerate}\n";
	}
	

}
