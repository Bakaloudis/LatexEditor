package model;

public class Section extends LatexCommands{
	public Section() {
		this.command = "\n\\section{}\n";
	}
	

	

}
