package model;

public class SubSection extends LatexCommands {

	public SubSection() {
		this.command = "\n\\subsection{}\n";
	}
	


}
