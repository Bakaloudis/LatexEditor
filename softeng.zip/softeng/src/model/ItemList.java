package model;

public class ItemList extends LatexCommands{

	public ItemList() {
		this.command = "\n\\begin{itemize}\r\n\n" + 
				"\\item ...\r\n\n" + 
				"\\item ...\r\n\n" + 
				"\\end{itemize}\n";
	}
	
	

}
