package model;

public class Chapter extends   LatexCommands{
	public Chapter(){
		this.command = "\n\\chapter{...}\n";
	}
	

}
