package model;

public class SubSubSection extends LatexCommands{

	public SubSubSection() {
		this.command = "\n\\subsubsection{}\n";
	}
	

}
