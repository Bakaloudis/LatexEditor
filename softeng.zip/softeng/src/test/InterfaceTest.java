package test;

import javax.swing.JTextArea;

public interface InterfaceTest {
	public void execute();
}
